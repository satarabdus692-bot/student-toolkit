# Add project specific ProGuard rules here.
# Room, Compose, and Navigation ship their own consumer rules, so this
# usually only needs entries if you add a reflection-heavy library later.
