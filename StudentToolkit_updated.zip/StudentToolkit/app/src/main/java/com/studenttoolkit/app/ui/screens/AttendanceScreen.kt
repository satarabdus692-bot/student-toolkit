package com.studenttoolkit.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studenttoolkit.app.data.dao.AttendanceDao
import com.studenttoolkit.app.data.dao.SubjectTotalDao
import com.studenttoolkit.app.data.entities.AttendanceRecord
import com.studenttoolkit.app.data.entities.SubjectTotal
import com.studenttoolkit.app.ui.theme.FloatingButton
import com.studenttoolkit.app.ui.theme.FloatingCard
import com.studenttoolkit.app.ui.theme.FloatingOutlinedButton
import com.studenttoolkit.app.ui.theme.FloatingTextField
import kotlinx.coroutines.launch
import java.util.Calendar

@Composable
fun AttendanceScreen(
    dao: AttendanceDao,
    subjectTotalDao: SubjectTotalDao,
    onBack: () -> Unit
) {
    val records by dao.getAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val subjectTotals by subjectTotalDao.getAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    var subject by remember { mutableStateOf("") }

    // Which subject's "set total classes" dialog is open (null = none open).
    var editingTotalsFor by remember { mutableStateOf<String?>(null) }
    // Which subject is pending delete confirmation.
    var deletingSubject by remember { mutableStateOf<String?>(null) }

    // Group records per subject to show a running percentage per subject.
    val bySubject = remember(records) { records.groupBy { it.subjectName } }
    val totalsBySubject = remember(subjectTotals) { subjectTotals.associateBy { it.subjectName } }
    // Union of subjects that have marked records AND subjects that only have a manual total set.
    val allSubjects = remember(bySubject, totalsBySubject) {
        (bySubject.keys + totalsBySubject.keys).toList().sorted()
    }

    Scaffold(topBar = { ToolTopBar(title = "Attendance Tracker", onBack = onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {

            FloatingTextField(
                value = subject,
                onValueChange = { subject = it },
                label = "Subject name",
                modifier = Modifier.fillMaxWidth()
            )

            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FloatingButton(
                    text = "Mark Present",
                    modifier = Modifier.weight(1f),
                    onClick = { markToday(scope, dao, subject, present = true) }
                )
                FloatingOutlinedButton(
                    text = "Mark Absent",
                    modifier = Modifier.weight(1f),
                    onClick = { markToday(scope, dao, subject, present = false) }
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))
            Text("By subject", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

            LazyColumn(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                items(allSubjects, key = { it }) { subjectName ->
                    val subjectRecords = bySubject[subjectName].orEmpty()
                    val markedCount = subjectRecords.size
                    val presentCount = subjectRecords.count { it.present }
                    val manualTotal = totalsBySubject[subjectName]?.totalClasses
                    val effectiveTotal = manualTotal?.takeIf { it > 0 } ?: markedCount
                    val percent = if (effectiveTotal == 0) 0.0 else (presentCount.toDouble() / effectiveTotal) * 100.0

                    FloatingCard(cornerRadius = 18.dp, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(subjectName, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                                Row {
                                    IconButton(onClick = { editingTotalsFor = subjectName }) {
                                        Icon(Icons.Filled.Edit, contentDescription = "Set total classes")
                                    }
                                    IconButton(onClick = { deletingSubject = subjectName }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Delete subject", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }

                            LinearProgressIndicator(
                                progress = { (percent / 100.0).toFloat().coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                            )

                            val totalLabel = if (manualTotal != null && manualTotal > 0) {
                                "$presentCount / $effectiveTotal classes attended (total set manually)"
                            } else {
                                "$presentCount / $markedCount classes attended"
                            }
                            Text(
                                "$totalLabel · ${String.format("%.1f", percent)}%",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    editingTotalsFor?.let { subjectName ->
        var totalInput by remember(subjectName) {
            mutableStateOf(totalsBySubject[subjectName]?.totalClasses?.toString() ?: "")
        }
        AlertDialog(
            onDismissRequest = { editingTotalsFor = null },
            title = { Text("Total classes — $subjectName") },
            text = {
                FloatingTextField(
                    value = totalInput,
                    onValueChange = { totalInput = it.filter { c -> c.isDigit() } },
                    label = "Total classes held",
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val total = totalInput.toIntOrNull()
                    if (total != null && total > 0) {
                        scope.launch { subjectTotalDao.upsert(SubjectTotal(subjectName, total)) }
                    }
                    editingTotalsFor = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editingTotalsFor = null }) { Text("Cancel") } }
        )
    }

    deletingSubject?.let { subjectName ->
        AlertDialog(
            onDismissRequest = { deletingSubject = null },
            title = { Text("Delete $subjectName?") },
            text = { Text("This removes every attendance record and the total-classes setting for this subject. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        dao.deleteBySubject(subjectName)
                        subjectTotalDao.deleteBySubject(subjectName)
                    }
                    deletingSubject = null
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deletingSubject = null }) { Text("Cancel") } }
        )
    }
}

private fun markToday(
    scope: kotlinx.coroutines.CoroutineScope,
    dao: AttendanceDao,
    subject: String,
    present: Boolean
) {
    if (subject.isBlank()) return
    scope.launch {
        dao.insert(
            AttendanceRecord(
                subjectName = subject.trim(),
                dateMillis = Calendar.getInstance().timeInMillis,
                present = present
            )
        )
    }
}
