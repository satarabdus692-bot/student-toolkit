package com.studenttoolkit.app.ui.screens

import android.content.Intent
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studenttoolkit.app.data.dao.NotePdfDao
import com.studenttoolkit.app.data.dao.NoteSubjectDao
import com.studenttoolkit.app.data.entities.NotePdf
import com.studenttoolkit.app.data.entities.NoteSubject
import com.studenttoolkit.app.ui.theme.FloatingBrandGradient
import com.studenttoolkit.app.ui.theme.FloatingCard
import com.studenttoolkit.app.ui.theme.FloatingTextField
import com.studenttoolkit.app.ui.theme.GradientIconBadge
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Notes, organized by subject. Each subject is a "notebook" you can attach as many
 * PDFs to as you like (pick several at once via the system file picker) — no
 * freeform text notes anymore, this screen is purely a per-subject PDF library.
 */
@Composable
fun NotesScreen(
    subjectDao: NoteSubjectDao,
    pdfDao: NotePdfDao,
    onBack: () -> Unit
) {
    val subjects by subjectDao.getAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val allPdfs by pdfDao.getAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var selectedSubject by remember { mutableStateOf<NoteSubject?>(null) }
    var addingSubject by remember { mutableStateOf(false) }
    var deletingSubject by remember { mutableStateOf<NoteSubject?>(null) }

    val pdfsBySubject = remember(allPdfs) { allPdfs.groupBy { it.subjectId } }

    val pickPdfsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val subject = selectedSubject ?: return@rememberLauncherForActivityResult
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            uris.forEach { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) {
                    // Some providers don't support persistable permissions — the PDF still
                    // opens fine for this session, it just may need re-picking after a reboot.
                }
                val displayName = queryDisplayName(context, uri) ?: "Document.pdf"
                pdfDao.insert(
                    NotePdf(
                        subjectId = subject.id,
                        uri = uri.toString(),
                        fileName = displayName,
                        addedAtMillis = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    if (selectedSubject == null) {
        // ---- Subject list ----
        Scaffold(
            topBar = { ToolTopBar(title = "Notes", onBack = onBack) },
            floatingActionButton = {
                FloatingActionButton(onClick = { addingSubject = true }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add subject")
                }
            }
        ) { padding ->
            if (subjects.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Folder, contentDescription = null, modifier = Modifier.padding(bottom = 12.dp))
                        Text("No subjects yet — tap + to add one", style = MaterialTheme.typography.titleMedium)
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize().padding(padding)
                ) {
                    items(subjects, key = { it.id }) { subject ->
                        val pdfCount = pdfsBySubject[subject.id]?.size ?: 0
                        FloatingCard(
                            cornerRadius = 20.dp,
                            onClick = { selectedSubject = subject },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    GradientIconBadge(icon = Icons.Filled.Folder)
                                    androidx.compose.foundation.layout.Spacer(Modifier.padding(start = 12.dp))
                                    Column {
                                        Text(subject.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            if (pdfCount == 1) "1 PDF" else "$pdfCount PDFs",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                IconButton(onClick = { deletingSubject = subject }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete subject", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        // ---- PDFs for the selected subject ----
        val subject = selectedSubject!!
        val pdfs = pdfsBySubject[subject.id].orEmpty()

        Scaffold(
            topBar = { ToolTopBar(title = subject.name, onBack = { selectedSubject = null }) },
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    pickPdfsLauncher.launch(arrayOf("application/pdf"))
                }) {
                    Icon(Icons.Filled.UploadFile, contentDescription = "Upload PDFs")
                }
            }
        ) { padding ->
            if (pdfs.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.padding(bottom = 12.dp))
                        Text("No PDFs yet — tap upload to add some", style = MaterialTheme.typography.titleMedium)
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize().padding(padding)
                ) {
                    items(pdfs, key = { it.id }) { pdf ->
                        FloatingCard(
                            cornerRadius = 18.dp,
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(pdf.uri.toUri(), "application/pdf")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    // No PDF viewer installed — silently ignore, the user can still
                                    // manage (delete) the attachment from this list.
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Filled.PictureAsPdf, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    androidx.compose.foundation.layout.Spacer(Modifier.padding(start = 10.dp))
                                    Column {
                                        Text(
                                            pdf.fileName,
                                            style = MaterialTheme.typography.bodyLarge,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(pdf.addedAtMillis)),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                    }
                                }
                                IconButton(onClick = { scope.launch { pdfDao.delete(pdf) } }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (addingSubject) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addingSubject = false },
            title = { Text("New subject") },
            text = {
                FloatingTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = "Subject name",
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (name.isNotBlank()) {
                            scope.launch {
                                subjectDao.insert(NoteSubject(name = name.trim(), createdAtMillis = System.currentTimeMillis()))
                            }
                        }
                        addingSubject = false
                    },
                    enabled = name.isNotBlank()
                ) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { addingSubject = false }) { Text("Cancel") } }
        )
    }

    deletingSubject?.let { subject ->
        AlertDialog(
            onDismissRequest = { deletingSubject = null },
            title = { Text("Delete ${subject.name}?") },
            text = { Text("This removes the subject and every PDF attached to it. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { subjectDao.delete(subject) }
                    if (selectedSubject?.id == subject.id) selectedSubject = null
                    deletingSubject = null
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deletingSubject = null }) { Text("Cancel") } }
        )
    }
}

/** Looks up a content:// URI's display file name via the OpenableColumns projection. */
private fun queryDisplayName(context: android.content.Context, uri: android.net.Uri): String? {
    return try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) else null
            } else null
        }
    } catch (_: Exception) {
        null
    }
}
