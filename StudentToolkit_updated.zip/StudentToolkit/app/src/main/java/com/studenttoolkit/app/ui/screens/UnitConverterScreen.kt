package com.studenttoolkit.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private enum class Category(val label: String, val units: List<Pair<String, Double>>) {
    // Values are "how many base units per 1 of this unit" (base = meters / kilograms)
    LENGTH("Length", listOf("mm" to 0.001, "cm" to 0.01, "m" to 1.0, "km" to 1000.0, "inch" to 0.0254, "foot" to 0.3048, "mile" to 1609.34)),
    WEIGHT("Weight", listOf("mg" to 0.000001, "g" to 0.001, "kg" to 1.0, "lb" to 0.453592, "oz" to 0.0283495)),
    TEMPERATURE("Temperature", listOf("°C" to 0.0, "°F" to 0.0, "K" to 0.0)) // handled specially, ratios unused
}

@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    var category by remember { mutableStateOf(Category.LENGTH) }
    var fromUnit by remember { mutableStateOf(category.units[0].first) }
    var toUnit by remember { mutableStateOf(category.units[1].first) }
    var inputValue by remember { mutableStateOf("") }

    val result = remember(inputValue, fromUnit, toUnit, category) {
        val input = inputValue.toDoubleOrNull()
        if (input == null) "" else convert(category, input, fromUnit, toUnit).let {
            if (it == it.toLong().toDouble()) it.toLong().toString() else String.format("%.4f", it)
        }
    }

    Scaffold(topBar = { ToolTopBar(title = "Unit Converter", onBack = onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Category.entries.forEach { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = {
                            category = cat
                            fromUnit = cat.units[0].first
                            toUnit = cat.units[1].first
                        },
                        label = { Text(cat.label) },
                        shape = RoundedCornerShape(12.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }
            }

            OutlinedTextField(
                value = inputValue,
                onValueChange = { inputValue = it.filter { c -> c.isDigit() || c == '.' || c == '-' } },
                label = { Text("Value") },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
            )

            Row(
                Modifier.fillMaxWidth().padding(top = 14.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                UnitDropdown(
                    label = "From", selected = fromUnit, options = category.units.map { it.first },
                    onSelected = { fromUnit = it }, modifier = Modifier.weight(1f)
                )
                FilledTonalIconButton(onClick = { val t = fromUnit; fromUnit = toUnit; toUnit = t }) {
                    Icon(Icons.Filled.SwapHoriz, contentDescription = "Swap")
                }
                UnitDropdown(
                    label = "To", selected = toUnit, options = category.units.map { it.first },
                    onSelected = { toUnit = it }, modifier = Modifier.weight(1f)
                )
            }

            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 28.dp)
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text(
                        "Result",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                    Text(
                        text = if (result.isEmpty()) "—" else "$result $toUnit",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
        }
    }
}

private fun convert(category: Category, value: Double, from: String, to: String): Double {
    if (category == Category.TEMPERATURE) {
        // Convert to Celsius first, then to target
        val celsius = when (from) {
            "°C" -> value
            "°F" -> (value - 32) * 5.0 / 9.0
            "K" -> value - 273.15
            else -> value
        }
        return when (to) {
            "°C" -> celsius
            "°F" -> celsius * 9.0 / 5.0 + 32
            "K" -> celsius + 273.15
            else -> celsius
        }
    }
    val fromFactor = category.units.first { it.first == from }.second
    val toFactor = category.units.first { it.first == to }.second
    return value * fromFactor / toFactor
}

@Composable
private fun UnitDropdown(
    label: String,
    selected: String,
    options: List<String>,
    onSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }, modifier = modifier) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.menuAnchor()
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = { onSelected(option); expanded = false })
            }
        }
    }
}
