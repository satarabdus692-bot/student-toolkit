package com.studenttoolkit.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studenttoolkit.app.ads.HomeBannerAd
import com.studenttoolkit.app.data.SettingsRepository
import com.studenttoolkit.app.navigation.Destination
import com.studenttoolkit.app.ui.theme.FloatingAccent
import com.studenttoolkit.app.ui.theme.FloatingBrandGradient
import com.studenttoolkit.app.ui.theme.FloatingCard
import com.studenttoolkit.app.ui.theme.FloatingPrimary
import com.studenttoolkit.app.ui.theme.FloatingSecondary
import kotlinx.coroutines.launch

// Cycles through the brand gradient's three tones so tool icon badges get visual
// variety without hardcoding per-destination colors.
private enum class AccentRole { PRIMARY, SECONDARY, ACCENT }

@Composable
fun HomeScreen(
    onToolClick: (Destination) -> Unit,
    settingsRepository: SettingsRepository
) {
    val scope = rememberCoroutineScope()
    val darkOverride by settingsRepository.darkModeOverride.collectAsStateWithLifecycle(initialValue = null)
    val isDarkOn = darkOverride == true

    Scaffold { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            // Floating header — app title + a glowing gradient dark-mode toggle,
            // not attached to the screen edge like a classic app bar.
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = "Student Toolkit",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Everything for your semester, in one place",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                androidx.compose.foundation.layout.Box(
                    modifier = Modifier
                        .size(48.dp)
                        .shadow(12.dp, CircleShape, ambientColor = FloatingPrimary.copy(alpha = 0.4f))
                        .clip(CircleShape)
                        .background(FloatingBrandGradient)
                        .then(
                            Modifier.background(
                                if (isDarkOn) Color.Transparent else Color.Transparent
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.material3.IconButton(
                        onClick = { scope.launch { settingsRepository.setDarkMode(!isDarkOn) } },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = if (isDarkOn) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                            contentDescription = "Toggle dark mode",
                            tint = Color.White
                        )
                    }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth().weight(1f)
            ) {
                items(Destination.toolGrid) { destination ->
                    val accent = AccentRole.entries[destination.ordinal % AccentRole.entries.size]
                    ToolCard(
                        title = destination.title,
                        icon = destination.icon,
                        implemented = destination.implemented,
                        accent = accent,
                        onClick = { onToolClick(destination) }
                    )
                }
            }

            // Banner ad anchored at the bottom of Home — see AdIds.kt to switch from test to real IDs.
            HomeBannerAd(modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ToolCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    implemented: Boolean,
    accent: AccentRole,
    onClick: () -> Unit
) {
    val gradient = when (accent) {
        AccentRole.PRIMARY -> Brush.linearGradient(listOf(FloatingPrimary, FloatingSecondary))
        AccentRole.SECONDARY -> Brush.linearGradient(listOf(FloatingSecondary, FloatingAccent))
        AccentRole.ACCENT -> Brush.linearGradient(listOf(FloatingAccent, FloatingPrimary))
    }

    FloatingCard(
        onClick = onClick,
        cornerRadius = 24.dp,
        modifier = Modifier.aspectRatio(1f).fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .size(44.dp)
                    .shadow(8.dp, RoundedCornerShape(16.dp), ambientColor = FloatingPrimary.copy(alpha = 0.4f))
                    .clip(RoundedCornerShape(16.dp))
                    .background(gradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Start
                )
                if (!implemented) {
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHighest
                    ) {
                        Text(
                            text = "Coming soon",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }
    }
}
