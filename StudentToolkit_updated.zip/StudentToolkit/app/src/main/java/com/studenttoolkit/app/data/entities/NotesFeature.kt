package com.studenttoolkit.app.data.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A subject "notebook" — Notes are organized by subject, and each subject can hold
 * many attached PDFs (see [NotePdf]).
 */
@Entity(tableName = "note_subjects")
data class NoteSubject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAtMillis: Long
)

/**
 * One uploaded PDF attached to a subject. [uri] is a persisted content:// URI string
 * (persistable read permission is taken when the file is picked — see NotesScreen.kt)
 * so it stays accessible after the app or device restarts.
 */
@Entity(
    tableName = "note_pdfs",
    foreignKeys = [
        ForeignKey(
            entity = NoteSubject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class NotePdf(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val uri: String,
    val fileName: String,
    val addedAtMillis: Long
)
