package com.studenttoolkit.app.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row = one course in one semester, used by the GPA/CGPA calculator.
 * gradePoint is on a 4.0 scale (edit the mapping in GpaCalculatorScreen if your
 * institution uses a different scale, e.g. 5.0 or 10.0).
 */
@Entity(tableName = "course_grades")
data class CourseGrade(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val semesterLabel: String,   // e.g. "Semester 1"
    val courseName: String,      // e.g. "Calculus I"
    val creditHours: Double,     // e.g. 3.0
    val gradePoint: Double,      // e.g. 4.0 for an A
    val marksObtained: Double? = null // set when the course was added via "Marks" mode (0-100)
)
