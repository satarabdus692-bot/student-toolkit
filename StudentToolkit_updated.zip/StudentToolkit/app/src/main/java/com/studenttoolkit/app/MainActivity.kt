package com.studenttoolkit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.ads.MobileAds
import com.studenttoolkit.app.data.AppDatabase
import com.studenttoolkit.app.data.SettingsRepository
import com.studenttoolkit.app.navigation.StudentToolkitNavHost
import com.studenttoolkit.app.ui.theme.StudentToolkitTheme

class MainActivity : ComponentActivity() {

    // Simple manual "DI": one Room database + one settings repository for the whole app.
    // If this grows, swap in Hilt — not needed for a project this size.
    private val database by lazy { AppDatabase.getInstance(applicationContext) }
    private val settingsRepository by lazy { SettingsRepository(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // One-time AdMob SDK init. Safe to call even before ad units are shown.
        MobileAds.initialize(this)
        // Warm up the first interstitial so it's ready by the time the user backs out of a tool.
        com.studenttoolkit.app.ads.InterstitialAdManager.preload(this)

        setContent {
            val darkOverride by settingsRepository.darkModeOverride.collectAsStateWithLifecycle(initialValue = null)

            StudentToolkitTheme(darkTheme = darkOverride) {
                val navController = rememberNavController()
                StudentToolkitNavHost(
                    navController = navController,
                    db = database,
                    settingsRepository = settingsRepository
                )
            }
        }
    }
}
