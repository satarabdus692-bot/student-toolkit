package com.studenttoolkit.app.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "assignments")
data class Assignment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String,
    val dueDateMillis: Long,
    val isDone: Boolean = false
)

@Entity(tableName = "timetable_entries")
data class TimetableEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayOfWeek: Int,       // 1 = Monday ... 7 = Sunday
    val startTimeMinutes: Int, // minutes since midnight
    val endTimeMinutes: Int,
    val subjectName: String,
    val location: String = ""
)

@Entity(tableName = "study_tasks")
data class StudyTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectName: String,
    val topic: String,
    val dateMillis: Long,       // planned study date
    val durationMinutes: Int,   // planned length of the session
    val isDone: Boolean = false
)
