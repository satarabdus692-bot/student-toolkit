package com.studenttoolkit.app.ads

import android.util.DisplayMetrics
import android.view.ViewGroup
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

/**
 * A single reusable banner ad, sized to the screen width (adaptive banner).
 * Drop this at the bottom of any screen — e.g. under the tool grid on Home.
 *
 * Ad unit ID comes from [AdIds.HOME_BANNER]. Swap that constant, not this file,
 * when you move from test ads to your real AdMob ad unit.
 */
@Composable
fun HomeBannerAd(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current

    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                adUnitId = AdIds.HOME_BANNER

                val displayMetrics: DisplayMetrics = ctx.resources.displayMetrics
                val adWidthPixels = displayMetrics.widthPixels.toFloat()
                val density = displayMetrics.density
                val adWidth = (adWidthPixels / density).toInt()

                setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(ctx, adWidth))
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
