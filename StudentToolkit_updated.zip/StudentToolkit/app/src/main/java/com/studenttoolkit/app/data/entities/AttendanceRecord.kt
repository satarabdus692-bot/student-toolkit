package com.studenttoolkit.app.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One row = one marked day for one subject. */
@Entity(tableName = "attendance_records")
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectName: String,
    val dateMillis: Long,    // epoch millis for the class date
    val present: Boolean
)

/**
 * Optional manual override for "total classes held" per subject — lets the percentage
 * be calculated against the real total class count even if not every single class was
 * marked present/absent day by day.
 */
@Entity(tableName = "subject_totals")
data class SubjectTotal(
    @PrimaryKey val subjectName: String,
    val totalClasses: Int
)
