package com.studenttoolkit.app.ads

/**
 * All AdMob ad unit IDs live here so there's exactly one place to swap
 * test IDs for real ones before a production release.
 *
 * These are currently Google's public TEST ad unit IDs — safe to ship,
 * but they will only ever show placeholder "Test Ad" creatives and earn
 * no revenue. Replace each value below with the real ad unit ID from your
 * AdMob console (Ads > Ad units) once your account + app are approved.
 *
 * Reference for the official test IDs: https://developers.google.com/admob/android/test-ads
 */
object AdIds {
    // Banner shown at the bottom of the Home screen.
    const val HOME_BANNER = "ca-app-pub-3940256099942544/6300978111" // TODO: replace before release

    // Optional: interstitial shown occasionally between tool screens.
    const val INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712" // TODO: replace before release
}
