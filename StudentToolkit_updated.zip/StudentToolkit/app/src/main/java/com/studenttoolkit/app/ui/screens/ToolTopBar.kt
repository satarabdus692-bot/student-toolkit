package com.studenttoolkit.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.studenttoolkit.app.ui.theme.FloatingBrandGradient
import com.studenttoolkit.app.ui.theme.FloatingPrimary
import com.studenttoolkit.app.ui.theme.FloatingSecondary

/**
 * Floating glass top bar: pill-shaped back button with a gradient glow, floating
 * (not edge-attached) title bar with rounded corners and a soft shadow, used across
 * every tool screen for a consistent premium look.
 */
@Composable
fun ToolTopBar(title: String, onBack: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(28.dp),
                ambientColor = FloatingPrimary.copy(alpha = 0.2f),
                spotColor = FloatingSecondary.copy(alpha = 0.2f)
            )
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f))
            .padding(horizontal = 10.dp, vertical = 10.dp)
    ) {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(FloatingBrandGradient)
                .then(
                    Modifier.background(Color.Transparent)
                ),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
        }
        androidx.compose.foundation.layout.Spacer(Modifier.size(14.dp))
        Text(
            text = title,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
