package com.studenttoolkit.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.studenttoolkit.app.data.entities.Assignment
import com.studenttoolkit.app.data.entities.StudyTask
import com.studenttoolkit.app.data.entities.TimetableEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface AssignmentDao {
    @Query("SELECT * FROM assignments ORDER BY dueDateMillis ASC")
    fun getAll(): Flow<List<Assignment>>
    @Insert suspend fun insert(assignment: Assignment)
    @Update suspend fun update(assignment: Assignment)
    @Delete suspend fun delete(assignment: Assignment)
}

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable_entries ORDER BY dayOfWeek, startTimeMinutes")
    fun getAll(): Flow<List<TimetableEntry>>
    @Insert suspend fun insert(entry: TimetableEntry)
    @Delete suspend fun delete(entry: TimetableEntry)
}

@Dao
interface StudyTaskDao {
    @Query("SELECT * FROM study_tasks ORDER BY isDone ASC, dateMillis ASC")
    fun getAll(): Flow<List<StudyTask>>
    @Insert suspend fun insert(task: StudyTask)
    @Update suspend fun update(task: StudyTask)
    @Delete suspend fun delete(task: StudyTask)
}
