package com.studenttoolkit.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.studenttoolkit.app.data.entities.NotePdf
import com.studenttoolkit.app.data.entities.NoteSubject
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteSubjectDao {
    @Query("SELECT * FROM note_subjects ORDER BY name")
    fun getAll(): Flow<List<NoteSubject>>

    @Insert
    suspend fun insert(subject: NoteSubject): Long

    // Room's CASCADE foreign key on NotePdf takes care of deleting its attached PDFs.
    @Delete
    suspend fun delete(subject: NoteSubject)
}

@Dao
interface NotePdfDao {
    @Query("SELECT * FROM note_pdfs ORDER BY addedAtMillis DESC")
    fun getAll(): Flow<List<NotePdf>>

    @Query("SELECT * FROM note_pdfs WHERE subjectId = :subjectId ORDER BY addedAtMillis DESC")
    fun getForSubject(subjectId: Long): Flow<List<NotePdf>>

    @Insert
    suspend fun insert(pdf: NotePdf)

    @Delete
    suspend fun delete(pdf: NotePdf)
}
