package com.studenttoolkit.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = FloatingPrimary,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    primaryContainer = androidx.compose.ui.graphics.Color(0xFFE9DDFF),
    onPrimaryContainer = androidx.compose.ui.graphics.Color(0xFF2A0A78),
    secondary = FloatingSecondary,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    secondaryContainer = androidx.compose.ui.graphics.Color(0xFFF3E1FF),
    onSecondaryContainer = androidx.compose.ui.graphics.Color(0xFF3B0A63),
    tertiary = FloatingAccent,
    onTertiary = androidx.compose.ui.graphics.Color(0xFF00363D),
    tertiaryContainer = androidx.compose.ui.graphics.Color(0xFFC6F5FF),
    onTertiaryContainer = androidx.compose.ui.graphics.Color(0xFF00343B),
    error = FloatingError,
    background = BackgroundLight,
    onBackground = androidx.compose.ui.graphics.Color(0xFF1B1B23),
    surface = SurfaceLight,
    onSurface = androidx.compose.ui.graphics.Color(0xFF1B1B23),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFFEDE7F9),
)

private val DarkColors = darkColorScheme(
    primary = BluePrimaryDark,
    onPrimary = androidx.compose.ui.graphics.Color(0xFF3A0090),
    primaryContainer = androidx.compose.ui.graphics.Color(0xFF3E2E7A),
    onPrimaryContainer = androidx.compose.ui.graphics.Color(0xFFE9DDFF),
    secondary = AmberTertiaryDark,
    onSecondary = androidx.compose.ui.graphics.Color(0xFF450B70),
    secondaryContainer = androidx.compose.ui.graphics.Color(0xFF4A2F70),
    onSecondaryContainer = androidx.compose.ui.graphics.Color(0xFFF3E1FF),
    tertiary = TealSecondaryDark,
    onTertiary = androidx.compose.ui.graphics.Color(0xFF00363D),
    tertiaryContainer = androidx.compose.ui.graphics.Color(0xFF0E4650),
    onTertiaryContainer = androidx.compose.ui.graphics.Color(0xFFC6F5FF),
    error = FloatingError,
    background = BackgroundDark,
    onBackground = androidx.compose.ui.graphics.Color(0xFFE4E7F0),
    surface = SurfaceDark,
    onSurface = androidx.compose.ui.graphics.Color(0xFFE4E7F0),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFF2A3548),
    surfaceContainerLow = androidx.compose.ui.graphics.Color(0xFF17223A),
    surfaceContainer = androidx.compose.ui.graphics.Color(0xFF1B2740),
    surfaceContainerHigh = androidx.compose.ui.graphics.Color(0xFF213047),
    surfaceContainerHighest = androidx.compose.ui.graphics.Color(0xFF283A56),
)

// Generously rounded floating-UI corners applied to every default Material3 component
// (Buttons, Cards, TextFields, etc.) so the whole app inherits the soft, floating look
// even on screens that haven't been individually rebuilt with the custom components yet.
private val FloatingShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

/**
 * Material You / Floating UI theme.
 *
 * On Android 12+ (API 31+) dynamic color is available but defaults to OFF here so the
 * app consistently shows the premium purple/pink/cyan Floating UI palette everywhere,
 * regardless of the user's wallpaper. Pass dynamicColor = true if you'd rather have it
 * follow the device wallpaper on supported devices.
 *
 * @param darkTheme null = follow system setting, true/false = user override
 * (the override value comes from DataStore, see SettingsRepository)
 */
@Composable
fun StudentToolkitTheme(
    darkTheme: Boolean? = null,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val useDark = darkTheme ?: isSystemInDarkTheme()
    val context = LocalContext.current

    val colors = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (useDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        useDark -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography,
        shapes = FloatingShapes,
        content = content
    )
}
