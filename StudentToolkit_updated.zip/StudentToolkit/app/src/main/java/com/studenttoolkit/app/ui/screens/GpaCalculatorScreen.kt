package com.studenttoolkit.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studenttoolkit.app.data.dao.CourseGradeDao
import com.studenttoolkit.app.data.entities.CourseGrade
import com.studenttoolkit.app.ui.theme.FloatingBrandGradientVertical
import com.studenttoolkit.app.ui.theme.FloatingButton
import com.studenttoolkit.app.ui.theme.FloatingCard
import com.studenttoolkit.app.ui.theme.FloatingSegmentedToggle
import com.studenttoolkit.app.ui.theme.FloatingTextField
import kotlinx.coroutines.launch

// Standard 4.0-scale letter grade -> grade point mapping, used in "Letter Grade" mode.
// Change this map if your institution uses a different scale (e.g. 5.0, 10.0, percentage).
private val gradeOptions = listOf(
    "A" to 4.0, "A-" to 3.7, "B+" to 3.3, "B" to 3.0, "B-" to 2.7,
    "C+" to 2.3, "C" to 2.0, "C-" to 1.7, "D" to 1.0, "F" to 0.0
)

// Marks -> GPA scale used in "Marks" mode: 50 marks is the minimum passing GPA (1.0),
// 84+ marks is a full 4.0, and everything between is interpolated in a straight line.
// Below 50 marks is a fail (0.0 grade point).
private fun marksToGradePoint(marks: Double): Double = when {
    marks < 50.0 -> 0.0
    marks >= 84.0 -> 4.0
    else -> 1.0 + (marks - 50.0) / (84.0 - 50.0) * 3.0
}

private fun gradePointToLetter(gp: Double): String = when {
    gp >= 4.0 -> "A"
    gp >= 3.7 -> "A-"
    gp >= 3.3 -> "B+"
    gp >= 3.0 -> "B"
    gp >= 2.7 -> "B-"
    gp >= 2.3 -> "C+"
    gp >= 2.0 -> "C"
    gp >= 1.7 -> "C-"
    gp >= 1.0 -> "D"
    else -> "F"
}

@Composable
fun GpaCalculatorScreen(dao: CourseGradeDao, onBack: () -> Unit) {
    val courses by dao.getAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()

    var semester by remember { mutableStateOf("Semester 1") }
    var courseName by remember { mutableStateOf("") }
    var credits by remember { mutableStateOf("") }
    var selectedGrade by remember { mutableStateOf(gradeOptions.first()) }
    var gradeMenuExpanded by remember { mutableStateOf(false) }
    var marks by remember { mutableStateOf("") }
    var entryModeIndex by remember { mutableIntStateOf(0) } // 0 = Letter Grade, 1 = Marks

    val marksValue = marks.toDoubleOrNull()
    val marksGradePoint = marksValue?.let { marksToGradePoint(it.coerceIn(0.0, 100.0)) }

    val cgpa = remember(courses) {
        val totalCredits = courses.sumOf { it.creditHours }
        if (totalCredits == 0.0) 0.0
        else courses.sumOf { it.creditHours * it.gradePoint } / totalCredits
    }

    Scaffold(topBar = { ToolTopBar(title = "GPA / CGPA Calculator", onBack = onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {

            FloatingCard(cornerRadius = 28.dp, modifier = Modifier.fillMaxWidth()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        androidx.compose.foundation.layout.Spacer(Modifier.padding(start = 6.dp))
                        Text(
                            "Overall CGPA",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = String.format("%.2f", cgpa),
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Text(
                "Add a course",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 24.dp, bottom = 10.dp)
            )

            FloatingSegmentedToggle(
                options = listOf("Letter Grade", "Marks (0-100)"),
                selectedIndex = entryModeIndex,
                onSelected = { entryModeIndex = it },
                modifier = Modifier.fillMaxWidth()
            )

            FloatingTextField(
                value = semester, onValueChange = { semester = it },
                label = "Semester label",
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            )
            FloatingTextField(
                value = courseName, onValueChange = { courseName = it },
                label = "Course name",
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            )

            if (entryModeIndex == 0) {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FloatingTextField(
                        value = credits,
                        onValueChange = { credits = it.filter { c -> c.isDigit() || c == '.' } },
                        label = "Credit hours",
                        keyboardType = KeyboardType.Decimal,
                        modifier = Modifier.weight(1f)
                    )

                    ExposedDropdownMenuBox(
                        expanded = gradeMenuExpanded,
                        onExpandedChange = { gradeMenuExpanded = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = selectedGrade.first,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Grade") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = gradeMenuExpanded) },
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.menuAnchor()
                        )
                        DropdownMenu(
                            expanded = gradeMenuExpanded,
                            onDismissRequest = { gradeMenuExpanded = false }
                        ) {
                            gradeOptions.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text("${option.first} (${option.second})") },
                                    onClick = { selectedGrade = option; gradeMenuExpanded = false }
                                )
                            }
                        }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FloatingTextField(
                        value = credits,
                        onValueChange = { credits = it.filter { c -> c.isDigit() || c == '.' } },
                        label = "Credit hours",
                        keyboardType = KeyboardType.Decimal,
                        modifier = Modifier.weight(1f)
                    )
                    FloatingTextField(
                        value = marks,
                        onValueChange = { input ->
                            marks = input.filter { c -> c.isDigit() || c == '.' }
                        },
                        label = "Marks (0-100)",
                        keyboardType = KeyboardType.Decimal,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (marksGradePoint != null) {
                    Text(
                        text = "→ ${gradePointToLetter(marksGradePoint)} · GPA ${String.format("%.2f", marksGradePoint)}" +
                            if ((marksValue ?: 0.0) < 50.0) "  (below 50 = fail)" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (marksGradePoint == 0.0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                Text(
                    "Scale: 50 marks → GPA 1.0 · 84+ marks → GPA 4.0 (interpolated in between, below 50 = 0.0)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            FloatingButton(
                text = "Add course",
                onClick = {
                    val creditValue = credits.toDoubleOrNull()
                    val resolvedGradePoint = if (entryModeIndex == 0) selectedGrade.second else marksGradePoint
                    val resolvedMarks = if (entryModeIndex == 1) marksValue else null

                    if (courseName.isNotBlank() && creditValue != null && creditValue > 0 && resolvedGradePoint != null) {
                        scope.launch {
                            dao.insert(
                                CourseGrade(
                                    semesterLabel = semester,
                                    courseName = courseName,
                                    creditHours = creditValue,
                                    gradePoint = resolvedGradePoint,
                                    marksObtained = resolvedMarks
                                )
                            )
                        }
                        courseName = ""
                        credits = ""
                        marks = ""
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 20.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(courses, key = { it.id }) { course ->
                    FloatingCard(cornerRadius = 16.dp, modifier = Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    course.courseName,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium
                                )
                                val marksSuffix = course.marksObtained?.let { " · ${it.toInt()} marks" } ?: ""
                                Text(
                                    "${course.semesterLabel} · ${course.creditHours} cr · GP ${String.format("%.2f", course.gradePoint)}$marksSuffix",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { scope.launch { dao.delete(course) } }) {
                                Icon(
                                    Icons.Filled.Delete,
                                    contentDescription = "Delete",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
