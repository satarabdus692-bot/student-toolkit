package com.studenttoolkit.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.studenttoolkit.app.data.dao.AssignmentDao
import com.studenttoolkit.app.data.dao.AttendanceDao
import com.studenttoolkit.app.data.dao.CourseGradeDao
import com.studenttoolkit.app.data.dao.NotePdfDao
import com.studenttoolkit.app.data.dao.NoteSubjectDao
import com.studenttoolkit.app.data.dao.StudyTaskDao
import com.studenttoolkit.app.data.dao.SubjectTotalDao
import com.studenttoolkit.app.data.dao.TimetableDao
import com.studenttoolkit.app.data.entities.Assignment
import com.studenttoolkit.app.data.entities.AttendanceRecord
import com.studenttoolkit.app.data.entities.CourseGrade
import com.studenttoolkit.app.data.entities.NotePdf
import com.studenttoolkit.app.data.entities.NoteSubject
import com.studenttoolkit.app.data.entities.StudyTask
import com.studenttoolkit.app.data.entities.SubjectTotal
import com.studenttoolkit.app.data.entities.TimetableEntry

@Database(
    entities = [
        CourseGrade::class,
        AttendanceRecord::class,
        SubjectTotal::class,
        NoteSubject::class,
        NotePdf::class,
        Assignment::class,
        TimetableEntry::class,
        StudyTask::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun courseGradeDao(): CourseGradeDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun subjectTotalDao(): SubjectTotalDao
    abstract fun noteSubjectDao(): NoteSubjectDao
    abstract fun notePdfDao(): NotePdfDao
    abstract fun assignmentDao(): AssignmentDao
    abstract fun timetableDao(): TimetableDao
    abstract fun studyTaskDao(): StudyTaskDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "student_toolkit.db"
                )
                    // No migration path defined yet — safe for early development;
                    // switch to a real Migration before you have real user data to preserve.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
