package com.studenttoolkit.app.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import kotlin.math.min
import kotlin.math.pow

/**
 * Loads and shows interstitial ads sparingly — every [SHOW_EVERY_N_OPENS] times the user
 * backs out of a tool screen, AND only if at least [MIN_INTERVAL_MS] has passed since the
 * last one was shown. Showing one on every back-press is a bad user experience and AdMob's
 * own policies frown on overly aggressive interstitial cadence, so this deliberately holds
 * back most of the time and just tops up the counter.
 *
 * The count-based gate alone isn't enough: if the user backs out of several tools in a
 * fast burst (e.g. quickly checking the calculator, then a note, then the timetable), the
 * count can hit a multiple of [SHOW_EVERY_N_OPENS] within a couple of seconds, which reads
 * as jarring even though it's "correct" by the counter. The time gate smooths that out.
 *
 * Usage: call [preload] once at app start (already wired in MainActivity), then call
 * [maybeShow] wherever a "back" action leaves a tool screen — see NavGraph.kt.
 */
object InterstitialAdManager {
    private const val SHOW_EVERY_N_OPENS = 3
    private const val MIN_INTERVAL_MS = 60_000L // don't show more than once a minute

    // Retry backoff for failed loads: 15s, 30s, 60s, ... capped at 5 min, so a network
    // hiccup doesn't leave the ad slot permanently empty, but also doesn't hammer AdMob.
    private const val BASE_RETRY_DELAY_MS = 15_000L
    private const val MAX_RETRY_DELAY_MS = 300_000L
    private const val MAX_RETRY_EXPONENT = 5 // 15s * 2^5 = 480s, then clamped to 300s

    private var toolCloseCount = 0
    private var lastShownAtMs = 0L
    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false
    private var consecutiveFailures = 0

    private val retryHandler = Handler(Looper.getMainLooper())

    fun preload(context: Context) {
        if (interstitialAd != null || isLoading) return
        isLoading = true
        InterstitialAd.load(
            context.applicationContext,
            AdIds.INTERSTITIAL,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoading = false
                    consecutiveFailures = 0
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isLoading = false
                    scheduleRetry(context.applicationContext)
                }
            }
        )
    }

    private fun scheduleRetry(context: Context) {
        val exponent = min(consecutiveFailures, MAX_RETRY_EXPONENT)
        consecutiveFailures++
        val delay = min(
            BASE_RETRY_DELAY_MS * 2.0.pow(exponent).toLong(),
            MAX_RETRY_DELAY_MS
        )
        retryHandler.postDelayed({ preload(context) }, delay)
    }

    /**
     * Call when the user is leaving a tool screen. Shows an ad if the close-count hits a
     * multiple of [SHOW_EVERY_N_OPENS], one is loaded, AND at least [MIN_INTERVAL_MS] has
     * passed since the last ad was shown; otherwise it's a no-op that just continues.
     * [onNavigate] always runs — either right away, or once the ad is dismissed — so the
     * caller's actual back-navigation never gets silently dropped.
     */
    fun maybeShow(activity: Activity, onNavigate: () -> Unit) {
        toolCloseCount++
        val ad = interstitialAd
        val now = SystemClock.elapsedRealtime()
        val cooldownElapsed = (now - lastShownAtMs) >= MIN_INTERVAL_MS

        if (toolCloseCount % SHOW_EVERY_N_OPENS == 0 && ad != null && cooldownElapsed) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    lastShownAtMs = SystemClock.elapsedRealtime()
                    preload(activity)
                    onNavigate()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    preload(activity)
                    onNavigate()
                }
            }
            ad.show(activity)
        } else {
            if (interstitialAd == null) preload(activity)
            onNavigate()
        }
    }
}
