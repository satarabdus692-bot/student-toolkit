package com.studenttoolkit.app.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================================
// Floating UI palette — premium glass/gradient design system
// (see ui/theme/FloatingUi.kt for the reusable components built on top of this)
// ============================================================================

val FloatingPrimary = Color(0xFF7C4DFF)
val FloatingSecondary = Color(0xFFA855F7)
val FloatingAccent = Color(0xFF22D3EE)
val FloatingBackground = Color(0xFF0F172A)
val FloatingSurface = Color(0xFF1E293B)
val FloatingSuccess = Color(0xFF10B981)
val FloatingError = Color(0xFFEF4444)

// Lighter tonal steps used for the light theme / on-light glass surfaces.
val FloatingBackgroundLight = Color(0xFFF3F1FF)
val FloatingSurfaceLight = Color(0xFFFFFFFF)

// Brand fallback palette used to build the Material3 color schemes below.
val BluePrimary = FloatingPrimary
val BluePrimaryDark = Color(0xFFB39BFF)
val TealSecondary = FloatingAccent
val TealSecondaryDark = Color(0xFF67E8F9)
val AmberTertiary = FloatingSecondary
val AmberTertiaryDark = Color(0xFFD8B4FE)
val BackgroundLight = FloatingBackgroundLight
val BackgroundDark = FloatingBackground
val SurfaceLight = FloatingSurfaceLight
val SurfaceDark = FloatingSurface
