package com.studenttoolkit.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.studenttoolkit.app.ui.theme.FloatingBrandGradient
import com.studenttoolkit.app.ui.theme.FloatingCard
import com.studenttoolkit.app.ui.theme.FloatingSegmentedToggle
import net.objecthunter.exp4j.ExpressionBuilder
import net.objecthunter.exp4j.function.Function as Exp4jFunction

/**
 * Calculator with two modes:
 *  - Basic: standard +-×÷ arithmetic (unchanged behaviour from before).
 *  - Scientific: trig (sin/cos/tan, degrees or radians), log/ln, powers, roots,
 *    reciprocal, percent, and the π / e constants — evaluated safely with exp4j
 *    instead of a hand-rolled parser.
 */

// Degree-aware trig functions registered with exp4j so "Deg" mode can plug straight
// into the same expression string without any custom string-rewriting per submit.
private val sinDeg = object : Exp4jFunction("sind", 1) {
    override fun apply(vararg args: Double) = Math.sin(Math.toRadians(args[0]))
}
private val cosDeg = object : Exp4jFunction("cosd", 1) {
    override fun apply(vararg args: Double) = Math.cos(Math.toRadians(args[0]))
}
private val tanDeg = object : Exp4jFunction("tand", 1) {
    override fun apply(vararg args: Double) = Math.tan(Math.toRadians(args[0]))
}

private enum class CalcMode { BASIC, SCIENTIFIC }
private enum class AngleUnit { DEG, RAD }

@Composable
fun CalculatorScreen(onBack: () -> Unit) {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var modeIndex by remember { mutableIntStateOf(0) }
    var angleUnit by remember { mutableStateOf(AngleUnit.DEG) }
    val mode = if (modeIndex == 0) CalcMode.BASIC else CalcMode.SCIENTIFIC

    fun evaluate() {
        result = try {
            val sanitized = expression
                .replace("×", "*")
                .replace("÷", "/")
                .replace("−", "-")
                .replace("π", Math.PI.toString())
                .replace("%", "/100")
            val builder = ExpressionBuilder(sanitized)
                .function(sinDeg).function(cosDeg).function(tanDeg)
            val value = builder.build().evaluate()
            if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()
        } catch (e: Exception) {
            "Error"
        }
    }

    val basicButtons = listOf(
        "7", "8", "9", "÷",
        "4", "5", "6", "×",
        "1", "2", "3", "−",
        "C", "0", ".", "+",
    )

    // Trig button labels append the degree/radian-aware function name automatically.
    fun trigFn(name: String) = if (angleUnit == AngleUnit.DEG) "${name}d(" else "$name("

    val scientificButtons = listOf(
        "sin" to { expression += trigFn("sin") }, "cos" to { expression += trigFn("cos") },
        "tan" to { expression += trigFn("tan") }, "(" to { expression += "(" }, ")" to { expression += ")" },
        "log" to { expression += "log10(" }, "ln" to { expression += "log(" },
        "√" to { expression += "sqrt(" }, "x²" to { expression += "^2" }, "x^y" to { expression += "^" },
        "π" to { expression += "π" }, "e" to { expression += Math.E.toString() },
        "1/x" to { expression += "^(-1)" }, "%" to { expression += "%" }, "⌫" to {
            if (expression.isNotEmpty()) expression = expression.dropLast(1)
        },
    )

    Scaffold(topBar = { ToolTopBar(title = "Calculator", onBack = onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {

            FloatingSegmentedToggle(
                options = listOf("Basic", "Scientific"),
                selectedIndex = modeIndex,
                onSelected = { modeIndex = it },
                modifier = Modifier.fillMaxWidth()
            )

            if (mode == CalcMode.SCIENTIFIC) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    FloatingSegmentedToggle(
                        options = listOf("Deg", "Rad"),
                        selectedIndex = if (angleUnit == AngleUnit.DEG) 0 else 1,
                        onSelected = { angleUnit = if (it == 0) AngleUnit.DEG else AngleUnit.RAD },
                        modifier = Modifier.fillMaxWidth(0.5f)
                    )
                }
            }

            FloatingCard(
                cornerRadius = 20.dp,
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 16.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text(
                        text = expression.ifEmpty { "0" },
                        style = MaterialTheme.typography.headlineMedium,
                        textAlign = TextAlign.End,
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = result,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                }
            }

            if (mode == CalcMode.SCIENTIFIC) {
                scientificButtons.chunked(5).forEach { row ->
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        row.forEach { (label, action) ->
                            CalcKey(label = label, modifier = Modifier.weight(1f), onClick = action)
                        }
                        // Pad the last (shorter) row so keys stay aligned.
                        repeat(5 - row.size) { androidx.compose.foundation.layout.Spacer(Modifier.weight(1f)) }
                    }
                }
            }

            basicButtons.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { label ->
                        CalcKey(
                            label = label,
                            modifier = Modifier.weight(1f),
                            accent = label in listOf("÷", "×", "−", "+"),
                            onClick = {
                                when (label) {
                                    "C" -> { expression = ""; result = "" }
                                    else -> expression += label
                                }
                            }
                        )
                    }
                }
                androidx.compose.foundation.layout.Spacer(Modifier.padding(top = 4.dp))
            }

            androidx.compose.material3.Button(
                onClick = { evaluate() },
                shape = RoundedCornerShape(20.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = androidx.compose.ui.graphics.Color.Transparent
                ),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(),
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(20.dp))
                    .background(FloatingBrandGradient)
            ) {
                Text(
                    "=",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(vertical = 14.dp)
                )
            }
        }
    }
}

@Composable
private fun CalcKey(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Boolean = false,
) {
    FloatingCard(
        onClick = onClick,
        cornerRadius = 16.dp,
        containerColor = if (accent) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = modifier.aspectRatio(1.3f)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                color = if (accent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
