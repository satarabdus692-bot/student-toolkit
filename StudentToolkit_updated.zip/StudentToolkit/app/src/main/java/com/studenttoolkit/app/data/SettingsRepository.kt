package com.studenttoolkit.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

/**
 * Stores small app-wide preferences locally (no network, no account needed).
 * Currently just the dark-mode override; add more keys here as you add settings.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val DARK_MODE_OVERRIDE = booleanPreferencesKey("dark_mode_override")
        val DARK_MODE_ENABLED = booleanPreferencesKey("dark_mode_enabled")
    }

    /** null = follow system, otherwise true/false */
    val darkModeOverride: Flow<Boolean?> = context.dataStore.data.map { prefs ->
        if (prefs[Keys.DARK_MODE_OVERRIDE] == true) prefs[Keys.DARK_MODE_ENABLED] else null
    }

    suspend fun setFollowSystem() {
        context.dataStore.edit { it[Keys.DARK_MODE_OVERRIDE] = false }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit {
            it[Keys.DARK_MODE_OVERRIDE] = true
            it[Keys.DARK_MODE_ENABLED] = enabled
        }
    }
}
