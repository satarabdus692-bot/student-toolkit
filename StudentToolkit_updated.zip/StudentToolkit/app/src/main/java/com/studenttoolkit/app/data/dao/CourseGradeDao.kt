package com.studenttoolkit.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.studenttoolkit.app.data.entities.CourseGrade
import kotlinx.coroutines.flow.Flow

@Dao
interface CourseGradeDao {
    @Query("SELECT * FROM course_grades ORDER BY semesterLabel, id")
    fun getAll(): Flow<List<CourseGrade>>

    @Insert
    suspend fun insert(courseGrade: CourseGrade)

    @Delete
    suspend fun delete(courseGrade: CourseGrade)
}
