package com.studenttoolkit.app.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.School
import androidx.compose.ui.graphics.vector.ImageVector

/** One entry per tool on the home grid. Add new tools here first, then build the screen + route. */
enum class Destination(val route: String, val title: String, val icon: ImageVector, val implemented: Boolean) {
    HOME("home", "Home", Icons.Filled.School, true),
    GPA_CALCULATOR("gpa_calculator", "GPA / CGPA Calculator", Icons.Filled.School, true),
    ATTENDANCE("attendance", "Attendance Tracker", Icons.Filled.Checklist, true),
    CALCULATOR("calculator", "Calculator", Icons.Filled.Calculate, true),
    UNIT_CONVERTER("unit_converter", "Unit Converter", Icons.Filled.SquareFoot, true),
    STUDY_PLANNER("study_planner", "Study Planner", Icons.Filled.EventNote, true),
    TIMETABLE("timetable", "Timetable", Icons.Filled.CalendarMonth, true),
    NOTES("notes", "Notes", Icons.Filled.Notes, true),
    ASSIGNMENTS("assignments", "Assignment Manager", Icons.Filled.Assignment, true),
    POMODORO("pomodoro", "Pomodoro Timer", Icons.Filled.Timer, true),
    PDF_SCANNER("pdf_scanner", "PDF Scanner", Icons.Filled.DocumentScanner, true),
    QR_SCANNER("qr_scanner", "QR Scanner", Icons.Filled.QrCodeScanner, true);

    companion object {
        val toolGrid = entries.filter { it != HOME }
    }
}
