package com.studenttoolkit.app.navigation

import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.studenttoolkit.app.ads.InterstitialAdManager
import com.studenttoolkit.app.data.AppDatabase
import com.studenttoolkit.app.data.SettingsRepository
import com.studenttoolkit.app.ui.screens.AssignmentsScreen
import com.studenttoolkit.app.ui.screens.AttendanceScreen
import com.studenttoolkit.app.ui.screens.CalculatorScreen
import com.studenttoolkit.app.ui.screens.GpaCalculatorScreen
import com.studenttoolkit.app.ui.screens.HomeScreen
import com.studenttoolkit.app.ui.screens.NotesScreen
import com.studenttoolkit.app.ui.screens.PdfScannerScreen
import com.studenttoolkit.app.ui.screens.PomodoroScreen
import com.studenttoolkit.app.ui.screens.QrScannerScreen
import com.studenttoolkit.app.ui.screens.StudyPlannerScreen
import com.studenttoolkit.app.ui.screens.TimetableScreen
import com.studenttoolkit.app.ui.screens.UnitConverterScreen

@Composable
fun StudentToolkitNavHost(
    navController: NavHostController,
    db: AppDatabase,
    settingsRepository: SettingsRepository
) {
    val context = LocalContext.current

    // Every tool screen's "back" action routes through here so an interstitial can show
    // every few closes (see InterstitialAdManager). Falls back to a plain pop if the
    // context isn't an Activity for some reason (shouldn't happen in practice).
    val goBack: () -> Unit = {
        val activity = context as? Activity
        if (activity != null) {
            InterstitialAdManager.maybeShow(activity) { navController.popBackStack() }
        } else {
            navController.popBackStack()
        }
    }

    NavHost(navController = navController, startDestination = Destination.HOME.route) {

        composable(Destination.HOME.route) {
            HomeScreen(
                onToolClick = { destination -> navController.navigate(destination.route) },
                settingsRepository = settingsRepository
            )
        }

        composable(Destination.GPA_CALCULATOR.route) {
            GpaCalculatorScreen(dao = db.courseGradeDao(), onBack = goBack)
        }

        composable(Destination.ATTENDANCE.route) {
            AttendanceScreen(dao = db.attendanceDao(), subjectTotalDao = db.subjectTotalDao(), onBack = goBack)
        }

        composable(Destination.CALCULATOR.route) {
            CalculatorScreen(onBack = goBack)
        }

        composable(Destination.UNIT_CONVERTER.route) {
            UnitConverterScreen(onBack = goBack)
        }

        composable(Destination.STUDY_PLANNER.route) {
            StudyPlannerScreen(dao = db.studyTaskDao(), onBack = goBack)
        }

        composable(Destination.TIMETABLE.route) {
            TimetableScreen(dao = db.timetableDao(), onBack = goBack)
        }

        composable(Destination.NOTES.route) {
            NotesScreen(subjectDao = db.noteSubjectDao(), pdfDao = db.notePdfDao(), onBack = goBack)
        }

        composable(Destination.ASSIGNMENTS.route) {
            AssignmentsScreen(dao = db.assignmentDao(), onBack = goBack)
        }

        composable(Destination.POMODORO.route) {
            PomodoroScreen(onBack = goBack)
        }

        composable(Destination.PDF_SCANNER.route) {
            PdfScannerScreen(onBack = goBack)
        }

        composable(Destination.QR_SCANNER.route) {
            QrScannerScreen(onBack = goBack)
        }
    }
}

