package com.studenttoolkit.app.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.studenttoolkit.app.data.entities.AttendanceRecord
import com.studenttoolkit.app.data.entities.SubjectTotal
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records ORDER BY dateMillis DESC")
    fun getAll(): Flow<List<AttendanceRecord>>

    @Query("SELECT DISTINCT subjectName FROM attendance_records ORDER BY subjectName")
    fun getSubjects(): Flow<List<String>>

    @Insert
    suspend fun insert(record: AttendanceRecord)

    @Query("DELETE FROM attendance_records WHERE id = :id")
    suspend fun deleteById(id: Long)

    /** Deletes every marked day for a subject — used when the whole subject is removed. */
    @Query("DELETE FROM attendance_records WHERE subjectName = :subjectName")
    suspend fun deleteBySubject(subjectName: String)
}

@Dao
interface SubjectTotalDao {
    @Query("SELECT * FROM subject_totals")
    fun getAll(): Flow<List<SubjectTotal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(total: SubjectTotal)

    @Query("DELETE FROM subject_totals WHERE subjectName = :subjectName")
    suspend fun deleteBySubject(subjectName: String)
}
