package com.studenttoolkit.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.os.CountDownTimer

private const val FOCUS_MINUTES = 25
private const val SHORT_BREAK_MINUTES = 5
private const val LONG_BREAK_MINUTES = 15
private const val SESSIONS_BEFORE_LONG_BREAK = 4

private enum class PomodoroPhase(val label: String, val minutes: Int) {
    FOCUS("Focus", FOCUS_MINUTES),
    SHORT_BREAK("Short break", SHORT_BREAK_MINUTES),
    LONG_BREAK("Long break", LONG_BREAK_MINUTES)
}

@Composable
fun PomodoroScreen(onBack: () -> Unit) {
    var phase by remember { mutableStateOf(PomodoroPhase.FOCUS) }
    var completedFocusSessions by remember { mutableIntStateOf(0) }
    var totalMillis by remember { mutableIntStateOf(phase.minutes * 60_000) }
    var remainingMillis by remember { mutableIntStateOf(totalMillis) }
    var isRunning by remember { mutableStateOf(false) }
    var timer by remember { mutableStateOf<CountDownTimer?>(null) }

    fun startTimer() {
        timer?.cancel()
        isRunning = true
        timer = object : CountDownTimer(remainingMillis.toLong(), 200) {
            override fun onTick(millisUntilFinished: Long) {
                remainingMillis = millisUntilFinished.toInt()
            }
            override fun onFinish() {
                isRunning = false
                remainingMillis = 0
                // Advance to the next phase automatically.
                if (phase == PomodoroPhase.FOCUS) {
                    completedFocusSessions += 1
                    phase = if (completedFocusSessions % SESSIONS_BEFORE_LONG_BREAK == 0)
                        PomodoroPhase.LONG_BREAK else PomodoroPhase.SHORT_BREAK
                } else {
                    phase = PomodoroPhase.FOCUS
                }
                totalMillis = phase.minutes * 60_000
                remainingMillis = totalMillis
            }
        }.start()
    }

    fun pauseTimer() {
        timer?.cancel()
        isRunning = false
    }

    fun resetTimer() {
        timer?.cancel()
        isRunning = false
        remainingMillis = totalMillis
    }

    fun skipPhase() {
        timer?.cancel()
        isRunning = false
        if (phase == PomodoroPhase.FOCUS) {
            completedFocusSessions += 1
            phase = if (completedFocusSessions % SESSIONS_BEFORE_LONG_BREAK == 0)
                PomodoroPhase.LONG_BREAK else PomodoroPhase.SHORT_BREAK
        } else {
            phase = PomodoroPhase.FOCUS
        }
        totalMillis = phase.minutes * 60_000
        remainingMillis = totalMillis
    }

    DisposableEffect(Unit) {
        onDispose { timer?.cancel() }
    }

    val minutes = (remainingMillis / 1000) / 60
    val seconds = (remainingMillis / 1000) % 60
    val progress = if (totalMillis == 0) 0f else remainingMillis.toFloat() / totalMillis.toFloat()

    val containerColor = when (phase) {
        PomodoroPhase.FOCUS -> MaterialTheme.colorScheme.primaryContainer
        PomodoroPhase.SHORT_BREAK -> MaterialTheme.colorScheme.secondaryContainer
        PomodoroPhase.LONG_BREAK -> MaterialTheme.colorScheme.tertiaryContainer
    }

    Scaffold(topBar = { ToolTopBar(title = "Pomodoro Timer", onBack = onBack) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = containerColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = phase.label,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp)
                )
            }

            Box(
                modifier = Modifier
                    .padding(top = 40.dp)
                    .fillMaxWidth(0.75f)
                    .aspectRatio(1f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    progress = { progress },
                    strokeWidth = 10.dp,
                    modifier = Modifier.fillMaxSize(),
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                )
                Text(
                    text = String.format("%02d:%02d", minutes, seconds),
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "Sessions completed today: $completedFocusSessions",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 24.dp)
            )

            Row(
                Modifier.fillMaxWidth().padding(top = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { if (isRunning) pauseTimer() else startTimer() },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        if (isRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text(if (isRunning) "Pause" else "Start")
                }
                OutlinedButton(
                    onClick = { resetTimer() },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                    Text("Reset")
                }
            }

            OutlinedButton(
                onClick = { skipPhase() },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) {
                Icon(Icons.Filled.SkipNext, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                Text("Skip to next phase")
            }
        }
    }
}
